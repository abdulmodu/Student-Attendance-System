<?php


include('config.php');





if (isset($_GET['std_roll_no']) && is_numeric($_GET['std_roll_no']))

{


$id = $_GET['std_roll_no'];

$result = mysqli_query($connect, "DELETE FROM student_table WHERE std_roll_no=$std_roll_no")

or die(mysqli_error($connect));



// redirect back to the view page

header("Location: student.php");

}

else

// if id isn't set, or isn't valid, redirect back to view page

{

header("Location: student.php");

}



?>