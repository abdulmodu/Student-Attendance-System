

<?php
header("Location: takeattendance.php");

error_reporting(E_ALL ^ E_DEPRECATED);
include("../config.php");

$st_value = $_POST['stid'];
$date = date('Y-m-d H:i:s');
$subjid=$_POST['subjid'];

if($st_value==0){
    $barcode = $_POST['barcode'];
    $result = mysqli_query($connect, "select std_roll_no from student_table where barcode = '$barcode'");
    $stid = mysqli_fetch_array($result)['std_roll_no'];
    $atten='P';
}else{
    $stid=$_POST['stid'];
    $atten=$_POST['attend_symbol'];
}

$query=mysqli_query($connect,"insert into tbl_attendance(StudentRollNumber,SubjectId,attendance,date)VALUES('$stid','$subjid','$atten','$date')");

mysqli_query($connect, $query);

?>

