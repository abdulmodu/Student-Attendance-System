<?php
session_start();
include_once '../config.php';
?> 

<html>
        <title>Take Attendance</title>
        <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jq.js"></script>
    
    <body>

    <div class="container">
       
        <!--- Navbar --->
               <nav class="navbar navbar-default">
              <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="home.php" style="padding-top:0px; padding-left:1px;" >
                    <img alt="SAS" style="width:38%;" src="../logo.png">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?> <span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="#">Settings</a></li>
                        <li><a href="logout.php">Logout</a></li>
                      </ul>
                    </li>
                  </ul>
                </div><!-- /.navbar-collapse -->
              </div><!-- /.container-fluid -->
            </nav>
        
        
        <?php  
            error_reporting(E_ALL ^ E_DEPRECATED);
            include("../config.php");?>
            <div class="form-container" style="margin-top: 120px;">
                <form method="post" action="saveattendance.php" role="form">
                 <!-- <div class="container"> -->
                 <div class="col-lg-3">
                  <div class="form-group">
            <?php
                  $qs=mysqli_query($connect,"select * from student_table");
                  ?>
                  <?php	
                  echo "<select class='form-control' name='stid' >";
                      echo"<option value=0>Barcode</option>";
                  while($stid=mysqli_fetch_row($qs))
                  {				
                   echo"
                   <option value=$stid[1]>$stid[2] </option>";
                   }
                      
                  echo "</select>"."<br>";
                      
                  ?>
                  </div>
                  </div> <!--col-lg-4-->
                   <div class="col-lg-3">
                  <?php
                  $qs1=mysqli_query($connect,"select * from subject_table where '{$_SESSION['username']}' = teacher_name");	
                  echo "<select class='form-control' name='subjid'>";			
                  while($subjid=mysqli_fetch_row($qs1))
                  {				
                   echo"
                   <option value=$subjid[0]>$subjid[1] </option>";
                   }
                  echo "</select>";?>
                  </div> <!--col-lg-4-->
                    <div class="col-lg-3"> <input class="form-control" placeholder="Barcode" name="barcode" type="text" id="barcode" autofocus> </div>
                  <input type="radio" name="attend_symbol" value="P" id="present" />Present
                  <input type="radio" name="attend_symbol" value="A" />Absent
                  <button type="submit" name="save" value="Save" class="btn btn-success btn-sm" id="check_barcode">Save</button>

                </form>
                
        </div>
        
        
    </div>
        
        <script></script>
    </body>
</html>