<?php
session_start();
include_once '../config.php';
?> 

<html>
        <title><?php echo $_SESSION['username']; ?>'s Home</title>
        <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- jQuery library -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <link href="../image/AUN.png" rel="icon">
    
    <body>

    <div class="container">
       
        <!--- Navbar --->
        <nav class="navbar navbar-default">
              <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="home.php" style="padding-top:0px; padding-left:1px;" >
                    <img alt="SAS" style="width:38%;" src="../logo.png">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?> <span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="settings.php">Settings</a></li>
                        <li><a href="logout.php">Logout</a></li>
                      </ul>
                    </li>
                  </ul>
                </div><!-- /.navbar-collapse -->
              </div><!-- /.container-fluid -->
            </nav>
        
        <?php
            $link = mysqli_connect("localhost", "root", "", "sdp");

            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

            // Attempt select query execution
            $sql = "SELECT * FROM tbl_attendance as a inner join subject_table as s on a.SubjectId = s.subject_no WHERE '{$_GET['std_roll_no']}' = a.StudentRollNumber";
            if($result = mysqli_query($link, $sql)){
                if(mysqli_num_rows($result) > 0){
                    echo "<table class='table table-bordered table-responsive' style='margin: 0 auto; margin-top: 130px; width: 640px;'>";
                        echo "<tr>";
                            echo "<th>Attendance</th>";
                            echo "<th>Date</th>";
                        echo "</tr>";
                    while($row = mysqli_fetch_array($result)){
                        echo "<tr>";
                            echo "<td>" . $row['attendance'] . "</td>";
                            echo "<td>" . $row['date'] . "</td>";
                        echo "</tr>";
                    } 
                    echo "</table>";
                    // Free result set
                    mysqli_free_result($result);
                } else{
                    echo "No records matching your query were found.";
                }
            } else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }

            // Close connection
            mysqli_close($link);
        ?>
        
        </div>
         <div style="width:11%;">
            <ul class="list-group">
              <li class="list-group-item list-group-item-success"><strong>P</strong>: Present</li>
              <li class="list-group-item list-group-item-warning"><strong>S</strong>: Sick</li>
              <li class="list-group-item list-group-item-danger"><strong>A</strong>: Absent</li>
            </ul>
        </div>
        
        <script></script>
    </body>
</html>