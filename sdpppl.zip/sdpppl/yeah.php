<html>
<head>
    <title>Issa Practice</title>
</head>
    <body>
        <h2>Q: Who is the coolest kid in Africa?</h2>
        <?
            $answer = "Abdulmuminu Modu";
            $type = gettype($answer);
            echo "<h2>The answer is $answer and its datatype is $type</h2>";
            echo is_string($answer);
            
        $dog = "James";
        $cat = "Isah";
        $lion = "simba";
        
        $pets = array($dog, $cat, $lion);
        echo "$pets[1]<br>";
        $pets[3] = "messi";
        
        "echo $pets[3]<br>";
        
        $Pdog = array(
            'name'=> "James",
            'type'=> "Dog",
            'color'=> "Black",
            'age'=> 10
        );
        $Pcat = array(
            'name'=> "Isah",
            'type'=> "Cat",
            'color'=> "Cream",
            'age'=> 3
        );
        $Plion = array(
            'name'=> "simba",
            'type'=> "Lion",
            'color'=> "Red",
            'age'=> 6
        );
        $animals = array($Pdog, $Pcat, $Plion);
        if($animals[2]['age']<10){
            echo "<h2>Your ".$animals[2]['type']." named ".$animals[2]['name']." is younger than 10 years</h2>";
        };
        echo "<br>";
        
        echo $animals[2]['age'];
        print('<br>');
        
        $number = 10;
        echo "<ul>";
        
        while($number >= 1){
            echo "<li>Number $number</li>";
            $number--;
        };
        
        echo "</ul>";
        $i = 0;
        while($i < count($animals)){
            echo "I have a " .$animals[$i]['type']. " that is named " .$animals[$i]['name']. ".<br>";
            $i++;
        };
        
        for($j=0; $j<count($animals); $j++){
            echo "I have a " .$animals[$j]['type']. " that is named " .$animals[$j]['name']. ".<br>";
        };
        
        foreach($animals as $animals){
            echo "I have a " .$animals['type']. " that is named " .$animals['name']. ".<br>";
            
        };
        echo "<table border='1px'>";
            echo "<tr><td>Number</td><td>Number Squared</td></tr>";
        for($k=1; $k<=5; $k++){
            $y = $k*$k;
            echo "<tr><td>$k</td><td>$y</td></tr>";
            unset($y);
        };
        echo "</table>";
        echo"<br>";
        //wddjfjfjffjfj
        
         echo "<table border='1px'>";
            echo "<tr><td>Number</td><td>Number Squared</td></tr>";
        for($k=1; $k<=5; $k++){
            if($k%2 == 0){
                $y = $k*$k;
            echo "<tr><td>$k</td><td>$y</td></tr>";
            unset($y);
            };
        };
        echo "</table>";
        echo"<br>";
        
        
        function WriteMsg(){
            echo "<h2>Whats up Mudafuckers</h2>";
        };
        
        WriteMsg();
        
        $browser = $_SERVER['HTTP_USER_AGENT'];
        $ipadd = $_SERVER['REMOTE_ADDR'];
        echo $browser;
        echo "<br>";
        echo $ipadd;
        
        phpinfo();
        
        ?>
        
    </body>
</html>