<?php 
    $connect = mysqli_connect("localhost","root","","sdp") or die("Could not connect to database");
?>